const express = require('express');
const BodyParser = require('body-parser');
const Mongoose = require('mongoose');
const UserRoute = require('../Routes/userRoutes');
require('dotenv/config');
// absolute path for sendfile, unlike above.
const app = express();
app.use(BodyParser.urlencoded({
  extended: true,
}));
app.use(BodyParser.json());
app.engine('html', require('ejs').renderFile);

app.get('/', (request, response) => {
  response.render('C:\\Users\\Zack\\Desktop\\SP2\\SeniorProjectTwo\\html\\index.html');
});

app.use('/', UserRoute);

(async () => {
  await Mongoose.connect(process.env.DB_CONNECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true,
  });
  app.listen(8080, 'localhost', () => {
  });
})();
